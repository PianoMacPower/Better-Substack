// This is just a placeholder for now
console.log('Better Substack extension loaded');

// Initialize state
let hideAllNotes = false;
let hideImageNotes = false;
let hideSuggestions = false;
let hideDialog = false;
let hideTagBrowser = false;

// Function to check if an element contains images
function hasImages(element) {
    // Look for post attachments with images
    const hasPostAttachment = element.querySelector('.postAttachment-eYV3fM');
    if (hasPostAttachment) {
        // Check if this is a linked article (has a title) rather than just an image
        const hasArticleTitle = hasPostAttachment.querySelector('.color-vibrance-primary-KHCdqV');
        if (hasArticleTitle) {
            console.log('Found linked article, not counting as image:', {
                element: element,
                attachment: hasPostAttachment,
                title: hasArticleTitle.textContent
            });
            return false;
        }
        
        console.log('Found post attachment with image:', {
            element: element,
            attachment: hasPostAttachment
        });
        return true;
    }

    // Also check for other Substack image containers
    const hasImageContent = element.querySelector(
        '[class*="imageCarousel"], ' +
        '[class*="imageGrid"], ' +
        '[class*="imageBubbles"], ' +
        '[class*="imageBubble"]'
    );

    if (hasImageContent) {
        console.log('Found image content:', {
            element: element,
            imageContent: hasImageContent,
            className: hasImageContent.className
        });
        return true;
    }

    return false;
}

// Function to hide an element
function hideElement(element) {
    element.style.display = 'none';
    element.style.margin = '0';
    element.style.padding = '0';
    element.style.height = '0';
    element.style.minHeight = '0';
}

// Function to show an element
function showElement(element) {
    element.style.display = '';
    element.style.margin = '';
    element.style.padding = '';
    element.style.height = '';
    element.style.minHeight = '';
}

// Function to update post visibility
function updateVisibility() {
    // Select all notes
    const notes = document.querySelectorAll('div[role="article"][aria-label="Note"]');
    console.log('Found notes:', notes.length);

    // Log all notes first
    console.log('All notes structure:', Array.from(notes).map(note => ({
        id: note.id,
        className: note.className,
        hasImg: note.querySelector('img') !== null,
        imageRelatedClasses: Array.from(note.getElementsByTagName('*'))
            .map(el => el.className)
            .filter(className => 
                className && 
                typeof className === 'string' && 
                (className.includes('image') || className.includes('Image'))
            )
    })));

    notes.forEach(note => {
        if (hideAllNotes) {
            hideElement(note);
        } else if (hideImageNotes && hasImages(note)) {
            console.log('Hiding note with images:', {
                noteId: note.id,
                className: note.className
            });
            hideElement(note);
        } else {
            showElement(note);
        }
    });
}

// Function to toggle suggestions banner visibility
function toggleSuggestionsBanner() {
    // Try to find the suggestions block using the specific path
    const suggestionsBlock = document.querySelector('#reader-nav-page-scroll > div > div > div > div > div > div.pencraft.pc-display-flex.pc-paddingTop-16.pc-justifyContent-center.pc-reset > div > div.pencraft.pc-display-flex.pc-flexDirection-column.pc-paddingBottom-20.pc-reset > div:nth-child(5) > div');
    
    if (suggestionsBlock) {
        console.log('Found suggestions block via direct path');
        if (hideSuggestions) {
            hideElement(suggestionsBlock);
        } else {
            showElement(suggestionsBlock);
        }
        return;
    }

    // Fallback: try to find it by class name pattern
    const suggestionsContainer = document.querySelector('div[class*="peopleYouMayKnow"]');
    if (suggestionsContainer) {
        console.log('Found suggestions container via class name');
        if (hideSuggestions) {
            hideElement(suggestionsContainer);
        } else {
            showElement(suggestionsContainer);
        }
    }
}

// Function to toggle dialog visibility
function toggleDialog() {
    const dialogBox = document.querySelector('#reader-nav-page-scroll > div > div > div > div > div > div.pencraft.pc-display-flex.pc-paddingTop-16.pc-justifyContent-center.pc-reset > div > div.pencraft.pc-display-flex.pc-flexDirection-column.pc-paddingTop-8.pc-paddingBottom-8.pc-reset.pullX-16-Js0olk > div');
    
    if (dialogBox) {
        console.log('Found dialog box');
        if (hideDialog) {
            hideElement(dialogBox);
        } else {
            showElement(dialogBox);
        }
    }
}

// Function to toggle tag browser visibility
function toggleTagBrowser() {
    const tagBrowser = document.querySelector('#reader-nav-page-scroll > div > div > div > div > div > div.pencraft.pc-display-flex.pc-flexDirection-column.pc-paddingTop-16.pc-paddingBottom-16.pc-paddingLeft-80.pc-mobile-paddingLeft-16.pc-paddingRight-48.pc-mobile-paddingRight-0.pc-position-relative.pc-reset > div');
    
    if (tagBrowser) {
        console.log('Found tag browser');
        if (hideTagBrowser) {
            hideElement(tagBrowser);
        } else {
            showElement(tagBrowser);
        }
    }
}

// Initialize from storage
browser.storage.local.get(['hideAllNotes', 'hideImageNotes', 'hideSuggestions', 'hideDialog', 'hideTagBrowser']).then((result) => {
    hideAllNotes = result.hideAllNotes || false;
    hideImageNotes = result.hideImageNotes || false;
    hideSuggestions = result.hideSuggestions || false;
    hideDialog = result.hideDialog || false;
    hideTagBrowser = result.hideTagBrowser || false;
    updateVisibility();
    toggleSuggestionsBanner();
    toggleDialog();
    toggleTagBrowser();
});

// Listen for messages from popup
browser.runtime.onMessage.addListener((message) => {
    if (message.action === 'updateFilters') {
        hideAllNotes = message.hideAllNotes;
        hideImageNotes = message.hideImageNotes;
        hideSuggestions = message.hideSuggestions;
        hideDialog = message.hideDialog;
        hideTagBrowser = message.hideTagBrowser;
        updateVisibility();
        toggleSuggestionsBanner();
        toggleDialog();
        toggleTagBrowser();
    }
});

// Observe DOM changes for dynamically loaded content
const observer = new MutationObserver((mutations) => {
    const hasNewNotes = mutations.some(mutation => {
        return Array.from(mutation.addedNodes).some(node => {
            if (node.nodeType !== 1) return false; // Not an element node
            
            // Check if the node is a note or contains notes
            return node.matches?.('div[role="article"][aria-label="Note"]') ||
                   node.querySelector?.('div[role="article"][aria-label="Note"]');
        });
    });

    if (hasNewNotes) {
        console.log('New notes detected, updating visibility');
        updateVisibility();
    }

    // Check for and toggle all elements
    toggleSuggestionsBanner();
    toggleDialog();
    toggleTagBrowser();
});

// Start observing
observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Initial update
console.log('Initial visibility update');
updateVisibility();

// Initial cleanup
toggleSuggestionsBanner();
toggleDialog();
toggleTagBrowser();
