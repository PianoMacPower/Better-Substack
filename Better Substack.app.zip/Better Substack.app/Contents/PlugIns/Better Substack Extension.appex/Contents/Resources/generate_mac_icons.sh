#!/bin/bash

# Set the target directory
TARGET_DIR="../Better Substack/Assets.xcassets/AppIcon.appiconset"

# Create target directory if it doesn't exist
mkdir -p "$TARGET_DIR"

# Generate all required sizes
magick icon.svg -background none -resize 16x16 "$TARGET_DIR/icon_16x16.png"
magick icon.svg -background none -resize 32x32 "$TARGET_DIR/icon_16x16@2x.png"
magick icon.svg -background none -resize 32x32 "$TARGET_DIR/icon_32x32.png"
magick icon.svg -background none -resize 64x64 "$TARGET_DIR/icon_32x32@2x.png"
magick icon.svg -background none -resize 128x128 "$TARGET_DIR/icon_128x128.png"
magick icon.svg -background none -resize 256x256 "$TARGET_DIR/icon_128x128@2x.png"
magick icon.svg -background none -resize 256x256 "$TARGET_DIR/icon_256x256.png"
magick icon.svg -background none -resize 512x512 "$TARGET_DIR/icon_256x256@2x.png"
magick icon.svg -background none -resize 512x512 "$TARGET_DIR/icon_512x512.png"
magick icon.svg -background none -resize 1024x1024 "$TARGET_DIR/icon_512x512@2x.png"

echo "Mac app icons generated successfully!" 