#!/bin/bash

# Create images directory if it doesn't exist
mkdir -p images

# Generate different sizes
convert -background none icon.svg -resize 16x16 images/icon-16.png
convert -background none icon.svg -resize 32x32 images/icon-32.png
convert -background none icon.svg -resize 48x48 images/icon-48.png
convert -background none icon.svg -resize 64x64 images/icon-64.png
convert -background none icon.svg -resize 128x128 images/icon-128.png
convert -background none icon.svg -resize 256x256 images/icon-256.png
convert -background none icon.svg -resize 512x512 images/icon-512.png

echo "Icon generation complete!" 