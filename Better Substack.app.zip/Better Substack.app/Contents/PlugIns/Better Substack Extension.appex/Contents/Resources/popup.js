document.addEventListener('DOMContentLoaded', () => {
    const hideAllNotesToggle = document.getElementById('hideAllNotes');
    const hideImageNotesToggle = document.getElementById('hideImageNotes');
    const hideSuggestionsToggle = document.getElementById('hideSuggestions');
    const hideDialogToggle = document.getElementById('hideDialog');
    const hideTagBrowserToggle = document.getElementById('hideTagBrowser');

    // Load saved preferences
    browser.storage.local.get(['hideAllNotes', 'hideImageNotes', 'hideSuggestions', 'hideDialog', 'hideTagBrowser']).then((result) => {
        hideAllNotesToggle.checked = result.hideAllNotes || false;
        hideImageNotesToggle.checked = result.hideImageNotes || false;
        hideSuggestionsToggle.checked = result.hideSuggestions || false;
        hideDialogToggle.checked = result.hideDialog || false;
        hideTagBrowserToggle.checked = result.hideTagBrowser || false;
    });

    // Add change listener to hideAllNotes toggle
    hideAllNotesToggle.addEventListener('change', () => {
        // Save preference
        browser.storage.local.set({ hideAllNotes: hideAllNotesToggle.checked });

        // If turning on hideAllNotes, disable hideImageNotes
        if (hideAllNotesToggle.checked) {
            hideImageNotesToggle.checked = false;
            hideImageNotesToggle.disabled = true;
            browser.storage.local.set({ hideImageNotes: false });
        } else {
            hideImageNotesToggle.disabled = false;
        }

        // Send message to content script
        browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'updateFilters',
                hideAllNotes: hideAllNotesToggle.checked,
                hideImageNotes: hideImageNotesToggle.checked,
                hideSuggestions: hideSuggestionsToggle.checked,
                hideDialog: hideDialogToggle.checked,
                hideTagBrowser: hideTagBrowserToggle.checked
            });
        });
    });

    // Add change listener to hideImageNotes toggle
    hideImageNotesToggle.addEventListener('change', () => {
        // Save preference
        browser.storage.local.set({ hideImageNotes: hideImageNotesToggle.checked });

        // Send message to content script
        browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'updateFilters',
                hideAllNotes: hideAllNotesToggle.checked,
                hideImageNotes: hideImageNotesToggle.checked,
                hideSuggestions: hideSuggestionsToggle.checked,
                hideDialog: hideDialogToggle.checked,
                hideTagBrowser: hideTagBrowserToggle.checked
            });
        });
    });

    // Add change listener to hideSuggestions toggle
    hideSuggestionsToggle.addEventListener('change', () => {
        // Save preference
        browser.storage.local.set({ hideSuggestions: hideSuggestionsToggle.checked });

        // Send message to content script
        browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'updateFilters',
                hideAllNotes: hideAllNotesToggle.checked,
                hideImageNotes: hideImageNotesToggle.checked,
                hideSuggestions: hideSuggestionsToggle.checked,
                hideDialog: hideDialogToggle.checked,
                hideTagBrowser: hideTagBrowserToggle.checked
            });
        });
    });

    // Add change listener to hideDialog toggle
    hideDialogToggle.addEventListener('change', () => {
        // Save preference
        browser.storage.local.set({ hideDialog: hideDialogToggle.checked });

        // Send message to content script
        browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'updateFilters',
                hideAllNotes: hideAllNotesToggle.checked,
                hideImageNotes: hideImageNotesToggle.checked,
                hideSuggestions: hideSuggestionsToggle.checked,
                hideDialog: hideDialogToggle.checked,
                hideTagBrowser: hideTagBrowserToggle.checked
            });
        });
    });

    // Add change listener to hideTagBrowser toggle
    hideTagBrowserToggle.addEventListener('change', () => {
        // Save preference
        browser.storage.local.set({ hideTagBrowser: hideTagBrowserToggle.checked });

        // Send message to content script
        browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'updateFilters',
                hideAllNotes: hideAllNotesToggle.checked,
                hideImageNotes: hideImageNotesToggle.checked,
                hideSuggestions: hideSuggestionsToggle.checked,
                hideDialog: hideDialogToggle.checked,
                hideTagBrowser: hideTagBrowserToggle.checked
            });
        });
    });
});
