// This is just a placeholder for now
console.log('Background script loaded');
